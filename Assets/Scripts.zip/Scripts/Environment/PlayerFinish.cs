using System.Collections.Generic;
using UnityEngine;
using System;

[RequireComponent(typeof(UnitSFX))]

public class PlayerFinish: MonoBehaviour
{
    private UnitSFX uSFX;

    [SerializeField] private LayerMask CollisionLayer;

    [SerializeField] private string finishSFX;
    [SerializeField] private GameObject finishVFX;

    public static event Action OnPlayerFinish;

	// Start is called before the first frame update
	void Start()
	{
		if (!uSFX) uSFX = GetComponent<UnitSFX>();
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if (!((CollisionLayer.value & (1 << col.transform.gameObject.layer)) > 0))
		{
			return;
		}

		uSFX.PlaySFX(finishSFX);
		if (finishVFX)
		{
			Instantiate(finishVFX, transform.position, Quaternion.identity);
		}

		OnPlayerFinish?.Invoke();
	}
}
