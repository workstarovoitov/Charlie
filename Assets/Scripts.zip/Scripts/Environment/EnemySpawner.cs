using UnityEngine;

[RequireComponent(typeof(UnitSFX))]

public class EnemySpawner : MonoBehaviour
{
    [SerializeField] private GameObject enemyPrefab;
    [SerializeField] private string spawnSFX;

    private UnitSFX uSFX;
    void Start()
    {
        if (!uSFX) uSFX = GetComponent<UnitSFX>();
    }

    public void Spawn()
    {
        GameObject enemy = Instantiate(enemyPrefab, transform.position, Quaternion.Euler(Vector3.zero));
        enemy.GetComponent<UnitMovement>().CurrentDirection = (DIRECTION) Mathf.Pow(-1, (int)Random.Range(1, 3));
        enemy.GetComponent<Rigidbody2D>().velocity = new Vector2(Random.Range(2, 4) * (int)enemy.GetComponent<UnitMovement>().CurrentDirection, Random.Range(5, 8));
        uSFX.PlaySFX(spawnSFX);
    }
}
