using UnityEngine;
using System.Collections;

[RequireComponent(typeof(UnitSFX))]

public class TeleportBody : MonoBehaviour, ITarget<GameObject>
{
	[SerializeField] private Transform originPoint;
	[SerializeField] private Transform spawnPoint;
	[SerializeField] private float speed = 10f;
	
	[SerializeField] private GameObject originPointVFX;
	[SerializeField] private GameObject destinationPointVFX;
	[SerializeField] private string teleportSFX;

	private UnitSFX uSFX;

	private float alpha = 0;
	private float alphaTarget = 1;
	private SpriteRenderer sr;
	private GameObject bodyToTeleport;

	public void SetTarget(GameObject target)
    {
		bodyToTeleport = target;
    }
	
	public void OnSpawn()
	{
		if (!bodyToTeleport)
        {
			Debug.LogWarning("Nothing to teleport");
			return;
        }
		if (!uSFX) uSFX = GetComponent<UnitSFX>();
		uSFX.PlaySFX(teleportSFX);

		if (originPointVFX)
		{
			Instantiate(originPointVFX, originPoint.position, Quaternion.identity);
		}
		if (destinationPointVFX)
		{
			Instantiate(destinationPointVFX, spawnPoint.position, Quaternion.identity);
		}
		
		bodyToTeleport.transform.position = spawnPoint.position;

		sr = bodyToTeleport.GetComponent<SpriteRenderer>();
		alpha = 0;
		alphaTarget = 1;
		sr.color = new Color(1f, 1f, 1f, alpha);
		if (bodyToTeleport.GetComponent<UnitMain>())
        {
			bodyToTeleport.GetComponent<UnitMain>().rb.velocity = Vector2.zero;
        }

		StartCoroutine(SetAlpha());
	}

	IEnumerator SetAlpha()
	{
		while (Mathf.Abs(alpha - alphaTarget) >= 0 && sr)
		{
			alpha = Mathf.Lerp(alpha, alphaTarget, Time.deltaTime * speed);
			sr.color = new Color(1f, 1f, 1f, alpha);
			yield return new WaitForFixedUpdate();
		}
	}
}
