﻿//Interface for all damagable objects

public interface IUsable
{
	void Use();
 }


