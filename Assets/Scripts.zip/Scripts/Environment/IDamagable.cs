public interface IDamagable<GameObject>
{
    bool Hit(GameObject hitObject);
}

