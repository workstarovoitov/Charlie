public interface ITarget<GameObject>
{
    void SetTarget(GameObject target);
}

