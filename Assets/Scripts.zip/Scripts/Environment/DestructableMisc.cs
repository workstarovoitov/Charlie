using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestructableMisc : MonoBehaviour, IDamagable<GameObject>
{
	[SerializeField] private GameObject[] groundSmallPiece;
	[SerializeField] private GameObject[] groundMediumPiece;
	[SerializeField] private GameObject[] groundHugePiece;

	[SerializeField] private Vector3Int piecesNum;

	public bool Hit(GameObject hit)
	{
		for (int i = 0; i < piecesNum.x; i++)
		{
			Instantiate(groundSmallPiece[Random.Range(0, groundSmallPiece.Length)], transform.position, Quaternion.Euler(Vector3.forward * Random.Range(30, 120)));
		}
		for (int i = 0; i < piecesNum.y; i++)
		{
			Instantiate(groundMediumPiece[Random.Range(0, groundMediumPiece.Length)], transform.position, Quaternion.Euler(Vector3.forward * Random.Range(30, 120)));
		}
		for (int i = 0; i < piecesNum.z; i++)
		{
			Instantiate(groundHugePiece[Random.Range(0, groundHugePiece.Length)], transform.position, Quaternion.Euler(Vector3.forward * Random.Range(30, 120)));
		}
		Destroy(gameObject);
		return true;
	}


}
