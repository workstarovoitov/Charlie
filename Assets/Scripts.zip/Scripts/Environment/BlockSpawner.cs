using UnityEngine;
using System.Collections;

[RequireComponent(typeof(UnitSFX))]

public class BlockSpawner : MonoBehaviour
{
    [SerializeField] private GameObject blockItem;
    [SerializeField] Sprite[] spritesList;
    [SerializeField] private Transform spawnPosition;

    [SerializeField] private GameObject spawnVFX;
    [SerializeField] private string spawnSFX;
    
    private UnitSFX uSFX;

    private GameObject block;
    private bool blockSpawned = false;
    private float spawnTime = 0;
    // Start is called before the first frame update
    void Start()
    {
        if (!uSFX) uSFX = GetComponent<UnitSFX>();
        GetComponent<SpriteRenderer>().sprite = spritesList[(int)0];
        SpawnBlock();
    }

    private void SpawnBlock()
    {
        blockSpawned = true;
        spawnTime = Time.time;
        block = Instantiate(blockItem, spawnPosition.position, Quaternion.Euler(Vector3.zero));
        block.GetComponent<GroundBlock>().SetSprite((int)0);
        if (spawnVFX)
        {
            Instantiate(spawnVFX, spawnPosition.position, Quaternion.identity);
        }
        uSFX.PlaySFX(spawnSFX);
    }


    private void Update()
    {

        if (!block && blockSpawned && Time.time - spawnTime > 2f)
        {
            blockSpawned = false;
        }
        if (!block && !blockSpawned)
        {
            blockSpawned = true;
            spawnTime = Time.time;
            StartCoroutine(SpawnBlockRoutine());
        }
    }

    IEnumerator SpawnBlockRoutine()
    {
        yield return new WaitForSeconds(1);
        SpawnBlock();
    }

}
