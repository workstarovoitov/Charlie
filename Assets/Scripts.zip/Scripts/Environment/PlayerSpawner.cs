using System.Collections.Generic;
using UnityEngine;
using Cinemachine;
using System;

public class PlayerSpawner : MonoBehaviour
{
    [SerializeField] private List<GameObject> players;
    [SerializeField] private Transform startPosition;
    [SerializeField] private CinemachineVirtualCamera vcam;

    public static event Action OnPlayerSpawn;

    // Start is called before the first frame update
    void Start()
    {
        int currentPlayer = PlayerPrefs.HasKey("currentPlayer") ? PlayerPrefs.GetInt("currentPlayer") : 0;
        GameObject player = Instantiate(players[currentPlayer], startPosition.position, Quaternion.Euler(Vector3.zero));
        GameObject camera = GameObject.FindGameObjectWithTag("MainCamera");

        CinemachineVirtualCamera vcam = camera.GetComponentInChildren<CinemachineVirtualCamera>();         
       
        vcam.Follow = player.transform;

        OnPlayerSpawn?.Invoke();
    }
}
