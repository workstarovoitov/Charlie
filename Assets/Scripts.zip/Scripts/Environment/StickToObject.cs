﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

class StickToObject : MonoBehaviour
{
    [SerializeField] private LayerMask CollisionLayer;

    private void OnTriggerEnter(Collider col)
    {
        if ((CollisionLayer.value & (1 << col.transform.gameObject.layer)) > 0)
        {
            col.gameObject.transform.SetParent(transform);
        }
    }

    private void OnTriggerExit(Collider col)
    {
        if ((CollisionLayer.value & (1 << col.transform.gameObject.layer)) > 0)
        {
            col.gameObject.transform.SetParent(null);
        }
    }
}
