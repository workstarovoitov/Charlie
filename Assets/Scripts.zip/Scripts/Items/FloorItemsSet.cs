using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloorItemsSet : MonoBehaviour
{
    [SerializeField] GameObject[] itemsList;

    [SerializeField] float spawnChanceOnFirstLayer;
    [SerializeField] float spawnChanceOnLastLayer;
    

    [SerializeField] float floorYMin;
    [SerializeField] float floorYMax;
    [SerializeField] float floorZ;
    [SerializeField] float floorXMin;
    [SerializeField] float floorXMax;
    [SerializeField] float xOffset;

    [SerializeField] private LayerMask spawnOnLayer;
    [SerializeField] private LayerMask skipLayer;

    void Start()
    {
        float chance;
        for (int j = 0; j <= (int)(floorYMax - floorYMin); j++)
        {
            chance = Remap((floorYMin + j), floorYMin, floorYMax, spawnChanceOnFirstLayer, spawnChanceOnLastLayer);


            for (int i = 0; i < (int)(floorXMax - floorXMin); i++)
            {
                if (IsGroundUnder(new Vector2(floorXMin + 0.5f + i, floorYMin + j)) && !IsNeedToSkip(new Vector2(floorXMin + 0.5f + i, floorYMin + j + 0.01f)))
                {
                    if (Random.Range(0f, 1f) < chance)
                    {
                        Vector3 spawnPos = new Vector3(floorXMin + 0.5f + i, floorYMin + j, floorZ);
                        //GameObject item = Instantiate(itemsList[Random.Range(0, itemsList.Length)], spawnPos, Quaternion.Euler(Vector3.up * 180 *(int)Random.Range(0, 2)));
                        GameObject item = Instantiate(itemsList[Random.Range(0, itemsList.Length)], spawnPos, Quaternion.identity);
                        item.transform.SetParent(gameObject.transform);
                    }
                }
            }
        }
    }

    public float Remap(float from, float fromMin, float fromMax, float toMin, float toMax)
    {
        var fromAbs = from - fromMin;
        var fromMaxAbs = fromMax - fromMin;

        var normal = fromAbs / fromMaxAbs;

        var toMaxAbs = toMax - toMin;
        var toAbs = toMaxAbs * normal;

        var to = toAbs + toMin;

        return to;
    }
    public bool IsGroundUnder(Vector2 pos)
    {
        if (Physics2D.Raycast(new Vector2(pos.x, pos.y + 0.1f), Vector3.down, 0.3f, spawnOnLayer) && !Physics2D.Raycast(new Vector2(pos.x, pos.y + 0.01f), Vector3.up, 0.1f, spawnOnLayer))
        {
            return true;
        }
        return false;
    }    
    public bool IsNeedToSkip(Vector2 pos)
    {
        return Physics2D.Raycast(pos, Vector3.up, 0.5f, skipLayer);
    }

}
