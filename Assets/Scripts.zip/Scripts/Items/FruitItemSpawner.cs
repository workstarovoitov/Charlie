using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FruitItemSpawner : MonoBehaviour
{
    [SerializeField] List<GameObject> fruitsList;

    // Start is called before the first frame update
    void Start()
    {
        GameObject item = Instantiate(fruitsList[Random.Range(0, fruitsList.Count)], transform.position, Quaternion.Euler(Vector3.zero));
        item.transform.SetParent(transform.parent.gameObject.transform);
        Destroy(gameObject);
    }

}
