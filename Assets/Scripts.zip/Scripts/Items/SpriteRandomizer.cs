using UnityEngine;

public class SpriteRandomizer : MonoBehaviour
{
    [SerializeField] Sprite[] spritesList;
    [SerializeField] SpriteRenderer[] spritesTargets;

    private void Start()
    {
        int spriteNum = Mathf.RoundToInt(Random.Range(0, spritesList.Length));
        for (int i = 0; i < spritesTargets.Length; i++)
        {
            spritesTargets[i].sprite = spritesList[spriteNum];
        }
    }
}
