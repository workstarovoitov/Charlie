﻿using UnityEngine;
using System;

[RequireComponent(typeof(UnitSFX))]

public class FruitItem : MonoBehaviour
{

    private UnitSFX uSFX;
    [SerializeField] private string collectFruitSFX;
    [SerializeField] private GameObject collectFruitVFX;
    
    public static event Action OnCollectFruit;
    
    public void Start()
    {
        if (!uSFX) uSFX = GetComponent<UnitSFX>();
    }

    public void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            OnCollectFruit?.Invoke();
            uSFX.PlaySFX(collectFruitSFX);
            if (collectFruitVFX)
            {
                Instantiate(collectFruitVFX, transform.position, Quaternion.identity);
            }
            Destroy(gameObject);
        }
    }
}
