using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MiscSpriteRandomizer : MonoBehaviour
{
    [SerializeField] Sprite[] spritesList;

    private void Start()
    {
        int spriteNum = Mathf.RoundToInt(Random.Range(0, spritesList.Length));

        GetComponent<SpriteRenderer>().sprite = spritesList[spriteNum];
        transform.rotation =  Quaternion.Euler(Vector3.up * 180 * (int)Random.Range(0, 2));

    }
}
