﻿using UnityEngine;
using System;
using MenuManagement;
[RequireComponent(typeof(UnitSFX))]

public class CoinItem : MonoBehaviour
{

    private UnitSFX uSFX;
    [SerializeField] private string collectCoinSFX;
    [SerializeField] private GameObject collectCoinVFX;
    [SerializeField] private int coinNum;

    private LevelsMenu lm;
    public static event Action OnCollectCoin;
    
    public void Start()
    {
        lm = FindObjectOfType<LevelsMenu>(true);
        if (lm && lm.Levels.LevelsList[lm.CurrentLevel].CoinEnabled.Length > coinNum)
        {
            gameObject.SetActive(lm.Levels.LevelsList[lm.CurrentLevel].CoinEnabled[coinNum]);
        }
        else
        {
            gameObject.SetActive(false);
        }

        if (!uSFX) uSFX = GetComponent<UnitSFX>();
    }

    public void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.CompareTag("Player"))
        {
            lm.Levels.LevelsList[lm.CurrentLevel].CoinEnabled[coinNum] = false;


            OnCollectCoin?.Invoke();
            uSFX.PlaySFX(collectCoinSFX);
            Instantiate(collectCoinVFX, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }
}
