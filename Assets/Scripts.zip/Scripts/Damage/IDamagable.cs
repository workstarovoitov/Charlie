﻿//Interface for all damagable objects

public interface IDamagable<HitObject> {
	
	void Hit(HitObject DO);

 }


