﻿using UnityEngine;
[CreateAssetMenu(menuName = "InventoryObject/BeerPotion")]

[System.Serializable]
public class BeerPotion : PotionItem
{
}
