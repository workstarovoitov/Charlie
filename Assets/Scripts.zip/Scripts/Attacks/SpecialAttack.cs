﻿using UnityEngine;

public abstract class SpecialAttack : MonoBehaviour
{
    // Inheritors have to implement this (just like with an interface)
    public abstract void OnSpecialAttack();
}



