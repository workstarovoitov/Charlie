﻿
public interface ISpawnUnit
{

    void OnSpawn();

}