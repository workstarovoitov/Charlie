using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Camera Shake Settings")]

public class CameraShakeSettings : ScriptableObject
{
		public float cameraShakeAmplitude;
		public float cameraShakeFrequency;
		public float cameraShakeDuration;
}
