﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VFXDestroyEvent : MonoBehaviour
{
    public void AE_DestroyVFX()
    {
        Destroy(gameObject);
    }
}
