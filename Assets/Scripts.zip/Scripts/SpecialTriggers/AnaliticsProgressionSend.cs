using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GameAnalyticsSDK;
public class AnaliticsProgressionSend : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        GameAnalytics.Initialize();
    }

    public void SendEventStart(string eventName)
    {
        GameAnalytics.NewProgressionEvent(GAProgressionStatus.Start, eventName);
    }
    public void SendEventComplete(string eventName)
    {
        GameAnalytics.NewProgressionEvent(GAProgressionStatus.Complete, eventName);
    }
    public void SendEventFail(string eventName)
    {
        GameAnalytics.NewProgressionEvent(GAProgressionStatus.Fail, eventName);
    }
    public void SendEventOthers(string eventName)
    {
        GameAnalytics.NewProgressionEvent(GAProgressionStatus.Undefined, eventName);
    }
}
