using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelSelectButton : MonoBehaviour
{
    [SerializeField] private Text levelNum;
    [SerializeField] private GameObject backgroundImg;
    [SerializeField] private GameObject lockImg;
    [SerializeField] private GameObject hammerImg;

    [SerializeField] private GameObject star1ImgBack;
    [SerializeField] private GameObject star2ImgBack;
    [SerializeField] private GameObject star3ImgBack;

    [SerializeField] private GameObject star1Img;
    [SerializeField] private GameObject star2Img;
    [SerializeField] private GameObject star3Img;

    public int LevelName
    {
        set
        {
            levelNum.text = value.ToString();
        }
    }
    public bool LevelClosed
    {
        set
        {
            backgroundImg.SetActive(value);
            lockImg.SetActive(value);
        }
    }   
    
    public bool LevelUnderConstraction
    {
        set
        {
            backgroundImg.SetActive(value);
            hammerImg.SetActive(value);

            star1Img.SetActive(!value);
            star2Img.SetActive(!value);
            star3Img.SetActive(!value);

            star1ImgBack.SetActive(!value);
            star2ImgBack.SetActive(!value);
            star3ImgBack.SetActive(!value);
        }
    }    
    
    public bool WinDamage
    {
        set
        {
            star1Img.SetActive(value);
        }
    }
    public bool WinTime
    {
        set
        {
            star2Img.SetActive(value);
        }
    }
    public bool WinFruits 
    {
        set
        {
            star3Img.SetActive(value);
        }
    }

}
