using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace MenuManagement
{
    [System.Serializable]
    public class LevelPack
    {
        [SerializeField] private string levelsPackName;
        public string LevelsPackName
        {
            get => levelsPackName;
        }
        [SerializeField] private Levels levels;
        public Levels Levels
        {
            get => levels;
        }
    }

    public class LevelsMenu : Menu<LevelsMenu>
    {
        [SerializeField] private LevelPack[] levelsPack;
        private Levels levels;
        [SerializeField] private GameObject levelButtons;
        [SerializeField] private GameObject levelUnlockPopup;
        [SerializeField] private GameObject levelUderConstructionPopup;
        
        [SerializeField] private GameObject levelPackName;

        Button[] bttns;
        private int currentPage = 0;
        private int currentLevel = -1;
        private int currentPack = 0;

        public int CurrentLevel
        {
            get => currentLevel;
        }
        public Levels Levels
        {
            get
            {
                levels = levelsPack[currentPack].Levels;
                return levels;
            }
        }

        // Start is called before the first frame update
        void Start()
        {
            UpdateWindow();
        }

        private void OnEnable()
        {
            UpdateWindow();
        }
        private void OnDisable()
        {
        }

        public override void UpdateWindow()
        {
            levelUnlockPopup.SetActive(false);
            levelUderConstructionPopup.SetActive(false);
            bttns = levelButtons.GetComponentsInChildren<Button>(true);

            levels = levelsPack[currentPack].Levels;
            ShowPage();
        }

        public void OnLevelPressed(int levelNum)
        {
            ButtonClick();

            currentLevel = levelNum + currentPage * bttns.Length;
            int coinsAmount = PlayerPrefs.HasKey("coinsAmount") ? PlayerPrefs.GetInt("coinsAmount") : 0;
            
            if (levels.LevelsList[currentLevel].UnderConstructon)
            {
                levelUderConstructionPopup.SetActive(true);
                return;
            }

            if (levels.LevelsList[currentLevel].LevelCost > 0)
            {
                levelUnlockPopup.SetActive(true);
                levelUnlockPopup.GetComponent<LevelUnlockPopup>().LevelName = levels.LevelsList[currentLevel].LevelNum;
                levelUnlockPopup.GetComponent<LevelUnlockPopup>().LevelCost = levels.LevelsList[currentLevel].LevelCost;
                levelUnlockPopup.GetComponent<LevelUnlockPopup>().CoinsAmount = coinsAmount;
                return;
            }
               
            LevelLoader.LoadLevel(levels.LevelsList[currentLevel].LevelSceneName);
            GameMenu.Open();
        }

        public void OnCommentsPress()
        {
            Application.OpenURL("market://details?id=" + Application.identifier);
        }

        public void ShowPage()
        {
            levels = levelsPack[currentPack].Levels;
            levelPackName.GetComponent<Text>().text = levelsPack[currentPack].LevelsPackName;
            for (int i = 0; i < bttns.Length; i++)
            {
                int lvlNum = i + currentPage * bttns.Length;
                if (lvlNum < levels.LevelsList.Count)
                {
                    bttns[i].gameObject.SetActive(true);
                    LevelSelectButton lvlBttn = bttns[i].GetComponentInChildren<LevelSelectButton>();

                    if (levels.LevelsList[lvlNum].UnderConstructon)
                    {
                        lvlBttn.LevelClosed = false;
                        lvlBttn.LevelUnderConstraction = true;
                    }
                    else
                    {
                        lvlBttn.LevelUnderConstraction = false;
                        if (PlayerPrefs.HasKey(levels.LevelsList[lvlNum].LevelSceneName + "Cost"))
                        {
                            levels.LevelsList[lvlNum].LevelCost = PlayerPrefs.GetInt(levels.LevelsList[lvlNum].LevelSceneName + "Cost");
                        }
                        if (PlayerPrefs.HasKey(levels.LevelsList[lvlNum].LevelSceneName + "NoDamadge"))
                        {
                            levels.LevelsList[lvlNum].NoDamadge = PlayerPrefs.GetInt(levels.LevelsList[lvlNum].LevelSceneName + "NoDamadge") > 0 ? true : false;
                        }
                        if (PlayerPrefs.HasKey(levels.LevelsList[lvlNum].LevelSceneName + "SecondsSpend"))
                        {
                            levels.LevelsList[lvlNum].SecondsSpend = PlayerPrefs.GetInt(levels.LevelsList[lvlNum].LevelSceneName + "SecondsSpend");
                        }
                        if (PlayerPrefs.HasKey(levels.LevelsList[lvlNum].LevelSceneName + "FruitsCollected"))
                        {
                            levels.LevelsList[lvlNum].FruitsCollected = PlayerPrefs.GetInt(levels.LevelsList[lvlNum].LevelSceneName + "FruitsCollected");
                        }

                        if (levels.LevelsList[lvlNum].CoinEnabled.Length > 0)
                        {
                            for (int j = 0; j < levels.LevelsList[lvlNum].CoinEnabled.Length; j++)
                            {
                                if (PlayerPrefs.HasKey(levels.LevelsList[lvlNum].LevelSceneName + "Coin" + levels.LevelsList[lvlNum].CoinEnabled[j]))
                                {
                                    levels.LevelsList[lvlNum].CoinEnabled[j] = PlayerPrefs.GetInt(levels.LevelsList[lvlNum].LevelSceneName + "Coin" + levels.LevelsList[lvlNum].CoinEnabled[j]) > 0 ? true : false;
                                }
                            }
                        }


                        lvlBttn.LevelClosed = levels.LevelsList[lvlNum].LevelCost > 0 ? true : false;

                        lvlBttn.WinDamage = levels.LevelsList[lvlNum].NoDamadge;
                        lvlBttn.WinTime = (levels.LevelsList[lvlNum].SecondsSpend > 0 && levels.LevelsList[lvlNum].SecondsSpend < levels.LevelsList[lvlNum].SecondsRecord) ? true : false;
                        lvlBttn.WinFruits = (levels.LevelsList[lvlNum].FruitsCollected >= levels.LevelsList[lvlNum].FruitsMax) ? true : false;

                    }
                    
                    lvlBttn.LevelName = levels.LevelsList[lvlNum].LevelNum;
                }
                else
                {
                    bttns[i].gameObject.SetActive(false);
                }
            }
        }

        public void OnChangePack(int pack)
        {
            ButtonClick();

            currentPack += pack;
            currentPack = (currentPack + levelsPack.Length) % levelsPack.Length;
            currentPage = 0;
            ShowPage();
        }


        public void OnChangePage(int page)
        {
            ButtonClick();

            Button[] bttns = levelButtons.GetComponentsInChildren<Button>(true);
            int maxPage = (levels.LevelsList.Count + bttns.Length - 1) / bttns.Length;
            currentPage += page;
            currentPage = (currentPage + maxPage) % maxPage;

            ShowPage();
        }

        public void OnUnlockPopupClose()
        {
            ButtonClick();
            levelUnlockPopup.SetActive(false);
        }
        public void OnUnderConstructionPopupClose()
        {
            ButtonClick();
            levelUderConstructionPopup.SetActive(false);
        }
        
        public void OnUnlockPopupBuy()
        {
            ButtonClick();
            levelUnlockPopup.SetActive(false);
            int coinsNum = PlayerPrefs.HasKey("coinsAmount") ? PlayerPrefs.GetInt("coinsAmount") : 0;
            if (levels.LevelsList[currentLevel].LevelCost <= coinsNum)
            {
                coinsNum -= levels.LevelsList[currentLevel].LevelCost;
                PlayerPrefs.SetInt("coinsAmount", coinsNum);
                PlayerPrefs.SetInt(levels.LevelsList[currentLevel].LevelSceneName + "Cost", 0);
                PlayerPrefs.Save();

                levels.LevelsList[currentLevel].LevelCost = 0;
                ShowPage();
            }
            else
            {
                ShopMenu.Open();
            }
        }
    }
}