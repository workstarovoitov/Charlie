using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace MenuManagement
{
    public class ShopMenu : Menu<ShopMenu>
    {
        [SerializeField] private Text coinsAmount;
        [SerializeField] private Text adsState;
        [SerializeField] private Button adsButton;
        private int coinsNum;
        private bool adsOff;

        private void Start()
        {
            UpdateWindow();
        }

        private void OnEnable()
        {
            UpdateWindow();
        }

        public override void UpdateWindow()
        {
            coinsNum = PlayerPrefs.HasKey("coinsAmount") ? PlayerPrefs.GetInt("coinsAmount") : 0;
            coinsAmount.text = coinsNum.ToString();
            adsOff = false;
            if (PlayerPrefs.HasKey("adsDisabled") && PlayerPrefs.GetInt("adsDisabled") > 0)
            {
                adsOff = true;
            }
            adsState.text = adsOff ? "ADS OFF" : "ADS ON";
            adsButton.interactable = !adsOff;
        }

        public void OnEnableADS()
        {
            PlayerPrefs.SetInt("coinsAmount", 0);
            PlayerPrefs.SetInt("adsDisabled", 0);
            PlayerPrefs.Save();
        }

        public void OnBuyItem(int itemNum)
        {
            ButtonClick();
            switch (itemNum)
            {
                case 0:
                    PlayerPrefs.SetInt("adsDisabled", 1);
                    PlayerPrefs.Save();
                    adsState.text = "ADS OFF";
                    adsButton.interactable = false;
                    break;
                case 1:
                    coinsNum += 10;
                    PlayerPrefs.SetInt("coinsAmount", coinsNum);
                    PlayerPrefs.Save();
                    coinsAmount.text = coinsNum.ToString();
                    break;
                case 2:
                    coinsNum += 50;
                    PlayerPrefs.SetInt("coinsAmount", coinsNum);
                    PlayerPrefs.Save();
                    coinsAmount.text = coinsNum.ToString();
                    break;
                case 3:
                    coinsNum += 100;
                    PlayerPrefs.SetInt("coinsAmount", coinsNum);
                    PlayerPrefs.Save();
                    coinsAmount.text = coinsNum.ToString();
                    break;
                default:
                    OnBackPressed();
                    break;
            }
        }
    }
}