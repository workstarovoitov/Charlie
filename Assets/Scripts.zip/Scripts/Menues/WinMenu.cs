using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

namespace MenuManagement
{
    public class WinMenu : Menu<WinMenu>
    {
        [SerializeField] private Text heartAmount;
        [SerializeField] private Text timeAmount;
        [SerializeField] private Text fruitAmount;

        [SerializeField] private GameObject heartImg;
        [SerializeField] private GameObject timeImg;
        [SerializeField] private GameObject fruitImg;

        private Level levelData;
        private int coinsNum;

        // Start is called before the first frame update

        private void OnEnable()
        {
            UpdateWindow();
        }
       
        public override void UpdateWindow()
        {
            LevelsMenu lm = FindObjectOfType<LevelsMenu>(true);
            if (lm && lm.CurrentLevel < 0)
            {
                return;
            }
            if (lm)
            {
                levelData = lm.Levels.LevelsList[lm.CurrentLevel];
            }
            else
            {
                Debug.LogWarning("GAMEMANAGER LevelsMenu Error!");
            }

            GameMenu gm = FindObjectOfType<GameMenu>(true);
            if (!gm)
            {
                Debug.LogWarning("GAMEMANAGER GameMenu Error!");
            }

            coinsNum = PlayerPrefs.HasKey("coinsAmount") ? PlayerPrefs.GetInt("coinsAmount") : 0;

            GameObject player = GameObject.FindGameObjectWithTag("Player");
            int healthMax = 0;
            int healthCurrent = 0;
            if (player)
            {
                healthMax = player.GetComponent<UnitHurt>().MaxHealth;
                healthCurrent = player.GetComponent<UnitHurt>().CurrentHealth;
            }
            heartAmount.text = healthCurrent.ToString() + "/" + healthMax.ToString();
            heartImg.SetActive(false);

            if (healthCurrent == healthMax)
            {
                heartImg.SetActive(true);
                if (!levelData.NoDamadge)
                {
                    PlayerPrefs.SetInt(levelData.LevelSceneName + "NoDamadge", 1);
                    PlayerPrefs.Save();

                    levelData.NoDamadge = true;
                    coinsNum++;
                }
            }

            timeAmount.text = gm.CurrentSeconds.ToString() + "/" + levelData.SecondsRecord.ToString();
            timeImg.SetActive(false);

            if (gm.CurrentSeconds > 0 && gm.CurrentSeconds <= levelData.SecondsRecord)
            {
                timeImg.SetActive(true);
                if (levelData.SecondsSpend > levelData.SecondsRecord || levelData.SecondsSpend == 0)
                {
                    coinsNum++;
                }

                if (levelData.SecondsSpend > gm.CurrentSeconds || levelData.SecondsSpend == 0)
                {
                    PlayerPrefs.SetInt(levelData.LevelSceneName + "SecondsSpend", gm.CurrentSeconds);
                    PlayerPrefs.Save();
                    levelData.SecondsSpend = gm.CurrentSeconds;
                }
            }

            fruitAmount.text = gm.FruitsNum.ToString() + "/" + levelData.FruitsMax.ToString();
            fruitImg.SetActive(false);
            if (gm.FruitsNum == levelData.FruitsMax)
            {
                fruitImg.SetActive(true);
                if (levelData.FruitsCollected != levelData.FruitsMax)
                {
                    PlayerPrefs.SetInt(levelData.LevelSceneName + "FruitsCollected", gm.FruitsNum);
                    PlayerPrefs.Save();

                    levelData.FruitsCollected = gm.FruitsNum;
                    coinsNum++;
                }
            }

            if (levelData.CoinEnabled.Length > 0)
            {
                for (int i = 0; i < levelData.CoinEnabled.Length; i++)
                {
                    if (gm.CoinsOnLevel[i] && !levelData.CoinEnabled[i])
                    {
                        coinsNum++;
                        PlayerPrefs.SetInt(levelData.LevelSceneName + "Coin" + i, 0);
                        PlayerPrefs.Save();
                    }
                }
            }

            PlayerPrefs.SetInt("coinsAmount", coinsNum);
            PlayerPrefs.Save();
        }

        public void OnRestartPressed()
        {
            ButtonClick();
            Time.timeScale = 1;
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            base.OnBackPressed();
        }


        public void OnLevelMenuPressed()
        {
            ButtonClick();
            Time.timeScale = 1;
            LevelLoader.LoadMainMenuLevel();
            MainMenu.Open();
            LevelsMenu.Open();
        }
    }
}