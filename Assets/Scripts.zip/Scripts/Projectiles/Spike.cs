using UnityEngine;

[RequireComponent(typeof(UnitSFX))]

public class Spike : MonoBehaviour
{
	private UnitSFX uSFX;

	[SerializeField] private LayerMask CollisionLayer;

	[SerializeField] private string hitSFX;
	[SerializeField] private GameObject hitVFX;

	// Start is called before the first frame update
	void Start()
    {
		if (!uSFX) uSFX = GetComponent<UnitSFX>();
    }

	void OnTriggerStay2D(Collider2D col)
	{
		if (!((CollisionLayer.value & (1 << col.transform.gameObject.layer)) > 0))
		{
			return;
		}

		IDamagable<GameObject> damagableObject = col.GetComponent(typeof(IDamagable<GameObject>)) as IDamagable<GameObject>;
		if (damagableObject != null)
		{
			damagableObject.Hit(gameObject);
		}
		uSFX.PlaySFX(hitSFX);
		if (hitVFX)
		{
			Instantiate(hitVFX, transform.position, Quaternion.identity);
		}
	}
}
