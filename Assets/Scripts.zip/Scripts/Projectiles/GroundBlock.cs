using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(UnitSFX))]

public class GroundBlock : MonoBehaviour, IDamagable<GameObject>
{
    private Rigidbody2D rb;
    private BoxCollider2D bc;
	private UnitSFX uSFX;

	private GameObject destructableGround;
	
	[SerializeField] private LayerMask GroundLayer;

	[SerializeField] private GameObject[] groundSmallPiece;
	[SerializeField] private GameObject[] groundMediumPiece;
	[SerializeField] private GameObject[] groundHugePiece;

	[SerializeField] private Vector3Int piecesNum;

	[SerializeField] private CameraShakeSettings shakeSettings;
	
	[SerializeField] Sprite[] spritesList;
	[SerializeField] private string morphSFX;

	private bool spriteUpdated = false;
	private float worldPosY;
	private bool groundTouched = false;
	void Start()
    {
		if (!bc) bc = GetComponent<BoxCollider2D>();
		if (!rb) rb = GetComponent<Rigidbody2D>();
		if (!uSFX) uSFX = GetComponent<UnitSFX>();
		destructableGround = GameObject.Find("Destructable");
	}

	private void Update()
    {
		if (!groundTouched)
        {
			if (IsGrounded())
            {
				worldPosY = transform.position.y;
				groundTouched = true;
			}
		}
        if (worldPosY - transform.position.y > 1)
        {
			IDamagable<GameObject> damagableObject = destructableGround.GetComponentInChildren(typeof(IDamagable<GameObject>)) as IDamagable<GameObject>;
			
			SpawnProjectiles();
			CameraShake.Instance.Shake(shakeSettings);

			uSFX.PlaySFX(morphSFX);
			Destroy(gameObject);
		}
	}

	public void SetSprite(int num)
    {
		spriteUpdated = true;
	}

	private void SpawnProjectiles()
    {
		for (int i = 0; i < piecesNum.x; i++)
		{
			Instantiate(groundSmallPiece[(int)0], transform.position, Quaternion.Euler(Vector3.forward * Random.Range(30, 120)));
		}
		for (int i = 0; i < piecesNum.y; i++)
		{
			Instantiate(groundMediumPiece[(int)0], transform.position, Quaternion.Euler(Vector3.forward * Random.Range(30, 120)));
		}
		for (int i = 0; i < piecesNum.z; i++)
		{
			Instantiate(groundHugePiece[(int)0], transform.position, Quaternion.Euler(Vector3.forward * Random.Range(30, 120)));
		}
	}

	public bool Hit(GameObject hit)
	{
		SpawnProjectiles();

		CameraShake.Instance.Shake(shakeSettings);

		Destroy(gameObject);
		return true;
	}

	public bool IsGrounded()
	{
		return Physics2D.Raycast(bc.bounds.center, Vector3.down, bc.bounds.size.y / 2 + bc.edgeRadius + 0.1f, GroundLayer);
	}
}
