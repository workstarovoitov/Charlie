﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.InputSystem;
using FMODUnity;
using FMOD.Studio;

class GroundProjectile: MonoBehaviour
{
	private SpriteRenderer sr;
	private Rigidbody2D rb;

	[SerializeField] private float speedLinear;
	[SerializeField] private float speedAngular;
	
	[SerializeField] private float fadeOutSpeed;
	
	[SerializeField] private Sprite[] sprites;


	void Start()
	{

		if (!sr) sr = GetComponent<SpriteRenderer>();
		if (!rb) rb = GetComponent<Rigidbody2D>();
		sr.sprite = sprites[Random.Range(0, sprites.Length)];
		speedLinear = Random.Range(speedLinear * 0.75f, speedLinear * 1.25f);
		fadeOutSpeed = Random.Range(fadeOutSpeed * 0.75f, fadeOutSpeed * 1.25f);
		rb.angularVelocity = Random.Range(speedAngular * 0.5f, speedAngular * 1.5f) * Mathf.Pow (-1, (int)Random.Range(1,3));
		rb.velocity = new Vector2(Mathf.Cos(Mathf.Deg2Rad * (transform.eulerAngles.z)) * speedLinear, Mathf.Sin(Mathf.Deg2Rad * (transform.eulerAngles.z)) * speedLinear);
		StartCoroutine(SetAlpha());
	}

    IEnumerator SetAlpha()
	{
		float alpha = sr.color.a;
		while (rb.velocity.y > 0)
		{
			yield return new WaitForFixedUpdate();
		}
		while (gameObject.activeSelf && Mathf.Abs(alpha - 0f) > .01f)
		{
			alpha = Mathf.Lerp(alpha, 0f, Time.deltaTime * fadeOutSpeed);
			sr.color = new Color(1f, 1f, 1f, alpha);
			yield return new WaitForFixedUpdate();
		}
		DestroyProjectile();
	}

	private void DestroyProjectile()
    {
		Destroy(gameObject);
    }
}
