using UnityEngine;

[RequireComponent(typeof(Rigidbody2D))]
[RequireComponent(typeof(UnitSFX))]

public class Bullet : MonoBehaviour
{
    private Rigidbody2D rb;
	private UnitSFX uSFX;

	[SerializeField] private LayerMask CollisionLayer;

    [SerializeField] private float speedLinear = 3f;
    [SerializeField] private float speedAngular = 3f;

	[SerializeField] private string hitSFX;
	[SerializeField] private GameObject hitVFX;


	//[SerializeField] private HitObject attack;

	// Start is called before the first frame update
	void Start()
    {
		if (!rb) rb = GetComponent<Rigidbody2D>();
		if (!uSFX) uSFX = GetComponent<UnitSFX>();
        
        rb.velocity = new Vector2(Mathf.Cos(Mathf.Deg2Rad * (transform.eulerAngles.z)) * speedLinear, Mathf.Sin(Mathf.Deg2Rad * (transform.eulerAngles.z)) * speedLinear);
        rb.angularVelocity = Random.Range(speedAngular * 0.5f, speedAngular * 2f);
    }

	void OnTriggerStay2D(Collider2D col)
	{
		if (!((CollisionLayer.value & (1 << col.transform.gameObject.layer)) > 0))
		{
			return;
		}

		IDamagable <GameObject> damagableObject = col.GetComponentInChildren(typeof(IDamagable<GameObject>)) as IDamagable<GameObject>;
		if (damagableObject != null)
		{
			if (!damagableObject.Hit(gameObject)) return;

		}
		uSFX.PlaySFX(hitSFX);

		if (hitVFX)
		{
			Instantiate(hitVFX, transform.position, Quaternion.Euler(Vector3.forward * Random.Range(0,360)));
		}
		Destroy(gameObject);
	}
}
