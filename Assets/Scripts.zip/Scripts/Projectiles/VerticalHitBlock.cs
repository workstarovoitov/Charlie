using UnityEngine;

public class VerticalHitBlock : MonoBehaviour
{

	[SerializeField] private LayerMask CollisionLayer;
	private Rigidbody2D rb;
	private Vector3 startPosition;
    private void Start()
    {
		if (!rb) rb = GetComponentInParent<Rigidbody2D>();
		startPosition = transform.localPosition;
	}
    private void Update()
    {
		transform.localPosition = startPosition + Vector3.up * 0.05f * System.Math.Sign(Mathf.RoundToInt(rb.velocity.y));
    }

    void OnTriggerEnter2D(Collider2D col)
	{
		if (!((CollisionLayer.value & (1 << col.transform.gameObject.layer)) > 0))
		{
			return;
		}

		IDamagable <GameObject> damagableObject = col.GetComponentInChildren(typeof(IDamagable<GameObject>)) as IDamagable<GameObject>;
		if (damagableObject != null)
		{
			if (GetComponentInParent<UnitJump>()) GetComponentInParent<UnitJump>().StopJump();
			if (!damagableObject.Hit(gameObject)) return;	
		}
	}
}
