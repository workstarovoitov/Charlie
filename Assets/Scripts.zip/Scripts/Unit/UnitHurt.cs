using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.InputSystem;

[RequireComponent(typeof(UnitMain))]

public class UnitHurt : MonoBehaviour, IDamagable<GameObject>
{
    private UnitMain uMain;
    [SerializeField] private Vector2 knockBackForce;
    [SerializeField] private float iTime;
    [SerializeField] private int maxHealth;
    public int MaxHealth
    {
        get => maxHealth;
    }
    [Header("Blink settings")]
    [SerializeField] private float offTime;
    [SerializeField] private float onTime;
    [SerializeField] private float offAlpha;


    [SerializeField] private string hurtSFX;
    [SerializeField] private string deathSFX;

    [SerializeField] private LayerMask deadLayer;       //layer for dead bodies
    [SerializeField] private CameraShakeSettings shakeSettings;

    private int incomeAttackDirection;
    public int IncomeAttackDirection
    {
        get => incomeAttackDirection;
    }
    private bool hitted = false;
    public bool Hitted
    {
        get => hitted;
    }

    private int currentHealth = 1;
    public int CurrentHealth
    {
        get => currentHealth;
        set => currentHealth = value;
    }
    private float lastHitTime = 0;                      // the last time when we were hit 

    void Start()
    {
        if (!uMain) uMain = GetComponent<UnitMain>();
        currentHealth = maxHealth;
        hitted = false;
    }


    public bool Hit(GameObject hit)
    {
        //skip hit if there are iframes
        if (Time.time < lastHitTime + iTime && lastHitTime > 0) return false;


        //skip if we are not in hitable states
        if (!uMain.uState.StatesReadyToHurt.Contains(uMain.uState.CurrentState))
        {
            return false;
        }

        //we are hit
        lastHitTime = Time.time;
        hitted = true;
        incomeAttackDirection = hit.transform.position.x > transform.position.x ? -1 : 1;

        //add a small force from the impact
        uMain.rb.velocity = (Vector2.right * knockBackForce.x * incomeAttackDirection + Vector2.up * knockBackForce.y);

        if (IsVisible())
        {
            CameraShake.Instance.Shake(shakeSettings);
        }

        CancelInvoke();
        StopAllCoroutines();

        //implement damadge
        currentHealth--;

        if (currentHealth > 0)
        {
            uMain.uSFX.PlaySFX(hurtSFX);
            uMain.uState.CurrentState = UNITSTATE.HURT;
            uMain.uAnimator.SetAnimatorTrigger("Hurt");

            StartCoroutine(Blink());
        }
       
        if (currentHealth == 0)
        {
            uMain.uSFX.PlaySFX(deathSFX);
            uMain.uState.Flying = false;
            gameObject.layer = (int)Mathf.Log(deadLayer.value, 2);
            uMain.uAnimator.SetAnimatorTrigger("Death");
            uMain.uState.CurrentState = UNITSTATE.HURT;
        }
        return true;
    }

    IEnumerator Blink()
    {
        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        bool fadeOff = true;
        while (Time.time < lastHitTime + iTime)
        {
            if (fadeOff)
            {
                sr.color = new Color(1f, 1f, 1f, offAlpha);
                yield return new WaitForSeconds(offTime);
            }
            else
            {
                sr.color = new Color(1f, 1f, 1f, 1f);
                yield return new WaitForSeconds(onTime);
            }
            fadeOff = !fadeOff;
        }
        yield return new WaitForFixedUpdate();
        sr.color = new Color(1f, 1f, 1f, 1f);
    }

    IEnumerator DeathAnimation()
    {
        while (!uMain.uState.CurrentGroundedState)
        {
            yield return new WaitForFixedUpdate();
        }

        uMain.uState.CurrentState = UNITSTATE.DEATH;
        uMain.rb.velocity = Vector2.zero;
        
        gameObject.layer = (int)Mathf.Log(deadLayer.value, 2);
    }
 
    public void AE_StopHurt()
    {
        uMain.uMovement.ResetState();
    }   
    public void AE_Death()
    {
        if (uMain.uState.Flying)
        {
            uMain.uState.Flying = false;
            uMain.uMovement.GravityScale = 4;
        }
        StartCoroutine(DeathAnimation());
    }

    public bool IsVisible()
    {
        Renderer m_Renderer = GetComponent<Renderer>();
        if (m_Renderer && m_Renderer.isVisible)
        {
            return true;
        }
        return false;
    }
}
