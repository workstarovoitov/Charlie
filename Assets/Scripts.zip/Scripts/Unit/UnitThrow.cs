using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.InputSystem;

[RequireComponent(typeof(UnitMain))]

public class UnitThrow : UnitAttack
{
    private UnitMain uMain;
    [SerializeField] private Vector2 bulletSpawnOffset;
    [SerializeField] private GameObject bullet;
    [SerializeField] private float angle = 45;
    [SerializeField] private string throwSFX;

    void Start()
    {
        if (!uMain) uMain = GetComponent<UnitMain>();
    }

    public override void OnAttack()
    {
        Throw();
    }

    public void OnThrow(InputValue input)
    {
        if (Mathf.RoundToInt(input.Get<float>()) > 0.1f)
        {
            Throw();
        }
    }
    
    public void Throw()
    {
        if (uMain.uState.StatesReadyToThrow.Contains(uMain.uState.CurrentState))
        {
            uMain.uState.CurrentState = UNITSTATE.ATTACK;
            uMain.uAnimator.SetAnimatorTrigger("Throw");
            return;
        }
    }

    public void AE_Throw()
    {
        float curAngle = (int)uMain.uMovement.CurrentDirection > 0 ? angle : 180 - angle;
         
        Instantiate(bullet, new Vector3(transform.position.x + bulletSpawnOffset.x * (int)uMain.uMovement.CurrentDirection, transform.position.y + bulletSpawnOffset.y, 0f), Quaternion.Euler(Vector3.forward * curAngle));
        uMain.uSFX.PlaySFX(throwSFX);
    }
    
    public void AE_StopThrow()
    {
        uMain.uMovement.ResetState();
    }
}
