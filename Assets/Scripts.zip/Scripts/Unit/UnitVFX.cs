using UnityEngine;

public class UnitVFX : MonoBehaviour
{
    public void SpawnVFX(GameObject vfx, int dir, bool child = false, float xOffset = 0, float yOffset = 0)
    {
        if (vfx != null)
        {
            // Set effect spawn position
            Vector3 vfxSpawnPosition = transform.position + new Vector3(xOffset * dir, yOffset, 0.0f);
            GameObject newVFX = Instantiate(vfx, vfxSpawnPosition, Quaternion.identity) as GameObject;
            // Turn dust in correct X direction
            newVFX.transform.localScale = newVFX.transform.localScale.x * new Vector3(dir, 1, 1);
            if (child)
            {
                newVFX.transform.parent = transform;
            }
        }
    }
}