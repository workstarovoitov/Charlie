using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using System;

[RequireComponent(typeof(UnitMain))]

public class EnemyDead : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private Vector2 knockBackForce;
    [SerializeField] private float angularSpeed;
    [SerializeField] private float gravityScale;

    private UnitMain uMain;
    private bool dead = false;

    void Start()
    {
        if (!uMain) uMain = GetComponent<UnitMain>();
    }

    void Update()
    {
        if (!dead && (uMain.uState.CurrentState == UNITSTATE.DEATH || (uMain.uState.CurrentState == UNITSTATE.IDLE && GetComponent<UnitHurt>().CurrentHealth == 0)))
        {
            dead = true;
            uMain.rb.velocity = (Vector2.right * knockBackForce.x * GetComponent<UnitHurt>().IncomeAttackDirection + Vector2.up * knockBackForce.y);
            uMain.rb.freezeRotation = false;
            uMain.rb.angularVelocity = Random.Range(0.25f * angularSpeed, 1.75f * angularSpeed);
            GetComponent<UnitMovement>().GravityScale = gravityScale;
            StartCoroutine(DeathFadeout());
        }
        
        if(GetComponent<UnitHurt>().CurrentHealth == 0 && transform.GetChild(0).gameObject.activeSelf)
        {
            transform.GetChild(0).gameObject.SetActive(false);
        }


    }

    IEnumerator DeathFadeout()
    {
        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        float alpha = 1; 
        while (gameObject.activeSelf && alpha > .01f)
        {
            alpha = Mathf.Lerp(alpha, 0, Time.deltaTime * speed);
            sr.color = new Color(1f, 1f, 1f, alpha);
            yield return new WaitForFixedUpdate();
        }
        Destroy(gameObject);
    }
}
