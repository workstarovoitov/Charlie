using UnityEngine;

[RequireComponent(typeof(UnitMain))]

class UnitFlap : MonoBehaviour
{
    private UnitMain uMain;
    [SerializeField] private float defaultFlapSpeed;
    [SerializeField] private float remapMultiplierMin = 0.5f;
    [SerializeField] private float remapMultiplierMax = 1.75f;

    [SerializeField] private string flapSFX;

    private float flapScale = 1f;
    void Start()
    {
        if (!uMain) uMain = GetComponent<UnitMain>();
    }

    public void SetFlapForce(float multiplier)
    {
        flapScale = remap(-1f, 1f, remapMultiplierMin, remapMultiplierMax, multiplier);
    }

    public void AE_Flap()
    {
        SetFlapForce(uMain.uMovement.InputDirection.y);
        uMain.rb.velocity = new Vector2(uMain.rb.velocity.x, defaultFlapSpeed * flapScale);
        uMain.uSFX.PlaySFX(flapSFX);
    }

    float remap(float origFrom, float origTo, float targetFrom, float targetTo, float value)
    {
        float rel = Mathf.InverseLerp(origFrom, origTo, value);
        return Mathf.Lerp(targetFrom, targetTo, rel);
    }
}