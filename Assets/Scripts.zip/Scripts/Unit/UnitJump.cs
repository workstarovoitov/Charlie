﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.InputSystem;

[RequireComponent(typeof(UnitMain))]

class UnitJump : MonoBehaviour
{
    private UnitMain uMain;
    [SerializeField] private int jumpIterationsNumDefault = 5;
    [SerializeField] private int jumpWallIterationsNum = 3;
    [SerializeField] private int jumpSecondIterationsNum = 3;

    [SerializeField] private float defaultJumpSpeed = 10f;
    [SerializeField] private float holdJumpSpeedDefault = 10f;
    [SerializeField] private float SecondJumpSpeed = 10f;
    [SerializeField] private float WallJumpSpeedX = 10f;
    [SerializeField] private float WallJumpSpeedY = 10f;
    [SerializeField] private bool allowDoubleJump = true;

    private int jumpIterationsNum;
    private float jumpSpeed;
    private float holdJumpSpeed;
    private bool secondJumpDone = false;
    public bool SecondJumpDone
    {
        get => secondJumpDone;
        set => secondJumpDone = value;
    }
    
    private bool jumpBttnHold = false;
    
    private bool jumpPerformed = false;
    private bool jumpWallPerformed = false;
    private bool jumpSecondPerformed = false;
    private bool restoreDefaults = false;
    private int wallJumpDirection;
    
    private GameObject platform = null;

    [SerializeField] private JumpSurfaceSettings[] surfaceSettings;

    private List<UNITSTATE> StatesReadyToJump = new List<UNITSTATE>
    {
        UNITSTATE.IDLE,
        UNITSTATE.WALK,
    };
    private List<UNITSTATE> StatesReadyToWallJump = new List<UNITSTATE>
    {
        UNITSTATE.WALLSLIDE,
    };
    private List<UNITSTATE> StatesReadyToSecondJump = new List<UNITSTATE>
    {
        UNITSTATE.FALL,
        UNITSTATE.JUMP,
        UNITSTATE.WALLJUMP,
    };
    private List<UNITSTATE> StatesJump = new List<UNITSTATE>
    {
        UNITSTATE.SECONDJUMP,
        UNITSTATE.JUMP,
        UNITSTATE.WALLJUMP,
    };

    void Start()
    {
        if (!uMain) uMain = GetComponent<UnitMain>();
        jumpIterationsNum = jumpIterationsNumDefault;
        jumpSpeed = defaultJumpSpeed;
        holdJumpSpeed = holdJumpSpeedDefault;
    }


    public void LateUpdate()
    {
        if (jumpPerformed)
        {
            uMain.rb.velocity = new Vector2(uMain.rb.velocity.x, jumpSpeed);
            StartCoroutine(AddForceJumpCoroutine());
           
            jumpPerformed = false;
        }

        if (jumpWallPerformed)
        {
            uMain.rb.velocity = new Vector2(wallJumpDirection * WallJumpSpeedX, WallJumpSpeedY);
            StartCoroutine(AddForceJumpWallCoroutine());
            
            jumpWallPerformed = false;
        }   
        
        if (jumpSecondPerformed)
        {
            uMain.rb.velocity = new Vector2(uMain.rb.velocity.x, SecondJumpSpeed);
            StartCoroutine(AddForceJumpSecondCoroutine());
            
            jumpSecondPerformed = false;
        }
    }

    public void OnJump(InputValue input)
    {
        if (Mathf.RoundToInt(input.Get<float>()) > 0.1f)
        {
            jumpBttnHold = true;

            //jump down from platform
            if (uMain.uState.CurrentGroundedState && uMain.uState.OnPlatform && uMain.uMovement.InputDirection.y < 0f)
            {
                platform = uMain.uCollisions.Platform;
                Physics2D.IgnoreCollision(transform.gameObject.GetComponent<Collider2D>(), platform.GetComponent<Collider2D>());
                uMain.uState.CurrentState = UNITSTATE.JUMPDOWN;
                uMain.uAnimator.SetAnimatorTrigger("Fall");
                StartCoroutine(OffSkipPlatformCorutine());
                return;
            }

            //default jump
            if (StatesReadyToJump.Contains(uMain.uState.CurrentState))
            {
                uMain.uState.CurrentState = UNITSTATE.JUMP;
                uMain.uAnimator.SetAnimatorTrigger("Jump");
                return;
            }

            //second jump
            if (StatesReadyToSecondJump.Contains(uMain.uState.CurrentState) && !secondJumpDone && allowDoubleJump)
            {
                uMain.uState.CurrentState = UNITSTATE.SECONDJUMP;
                uMain.uAnimator.SetAnimatorTrigger("JumpSecond");
                jumpSecondPerformed = true;
                secondJumpDone = true;
                return;
            }

            //wall jump
            if (StatesReadyToWallJump.Contains(uMain.uState.CurrentState))
            {
                uMain.uMovement.ReverseDirection();
                uMain.uState.CurrentState = UNITSTATE.WALLJUMP;
                uMain.uAnimator.SetAnimatorTrigger("JumpWall");
                return;
            }
        }
        else
        {
            jumpBttnHold = false;
        }
    }
    public void OnJumpDown(InputValue input)
    {
        if (Mathf.RoundToInt(input.Get<float>()) > 0.1f)
        {
            //jump down from platform
            if (uMain.uState.CurrentGroundedState && uMain.uState.OnPlatform && uMain.uMovement.InputDirection.y < 0f)
            {
                platform = uMain.uCollisions.Platform;
                Physics2D.IgnoreCollision(transform.gameObject.GetComponent<Collider2D>(), platform.GetComponent<Collider2D>());
                uMain.uState.CurrentState = UNITSTATE.JUMPDOWN;
                uMain.uAnimator.SetAnimatorTrigger("Fall");
                StartCoroutine(OffSkipPlatformCorutine());
                return;
            }
        }
    }


    
    public void AE_AddJumpForce()
    {
        jumpPerformed = true;
        float dustYOffset = -(uMain.bc.bounds.size.y / 2 - uMain.bc.offset.y / 2) ;


        int i = 0;
        for (; i < surfaceSettings.Length; i++)
        {
            string surface = System.Enum.GetName(typeof(MATERIALS), surfaceSettings[i].surfaceTag);
            if (uMain.uState.SurfaceMaterial.Equals(surface))
            {
                uMain.uSFX.PlaySFX(surfaceSettings[i].jumpSFX);
                uMain.uVFX.SpawnVFX(surfaceSettings[i].jumpVFX, (int)uMain.uMovement.CurrentDirection, false, 0.0f, dustYOffset);
            }
        }
    }

    public void AE_AddWallJumpForce()
    {
        wallJumpDirection = (int)Mathf.Sign((int)uMain.uMovement.CurrentDirection);
        jumpWallPerformed = true;

        int i = 0;
        for (; i < surfaceSettings.Length; i++)
        {
            string surface = System.Enum.GetName(typeof(MATERIALS), surfaceSettings[i].surfaceTag);
            if (uMain.uState.SurfaceMaterial.Equals(surface))
            {
                uMain.uSFX.PlaySFX(surfaceSettings[i].jumpSFX);
                uMain.uVFX.SpawnVFX(surfaceSettings[i].wJumpVFX, (int)uMain.uMovement.CurrentDirection);
            }
        }
    }

    public void StopJump()
    {
        jumpBttnHold = false;
        jumpPerformed = false;
        jumpWallPerformed = false;
        jumpSecondPerformed = false;
        uMain.rb.velocity = new Vector2(uMain.rb.velocity.x, 0);
        StopAllCoroutines();
        if (uMain.uState.CurrentState != UNITSTATE.ATTACK)
        {
            uMain.uMovement.ResetState();
        }
    }

    public void SetSurfaceJumpLimits(int jumpNum, float jumpSpeedMultiplexer)
    {
        jumpIterationsNum = jumpNum;
        jumpSpeed *= jumpSpeedMultiplexer;
        holdJumpSpeed *= jumpSpeedMultiplexer;


    }
    public void SetDefaultJumpLimits()
    {
        restoreDefaults = true;
    }
    IEnumerator AddForceJumpCoroutine()
    {
        int i = 0;
        yield return new WaitForFixedUpdate();
        while ( (jumpBttnHold && i < jumpIterationsNum) )
        {
            if (StatesJump.Contains(uMain.uState.CurrentState))
            {
                uMain.rb.velocity = new Vector3(uMain.rb.velocity.x, holdJumpSpeed);
            }                
            i++;

            yield return new WaitForFixedUpdate();
        }
        if (restoreDefaults)
        {
            jumpIterationsNum = jumpIterationsNumDefault;
            jumpSpeed = defaultJumpSpeed;
            holdJumpSpeed = holdJumpSpeedDefault;

            restoreDefaults = false;
        }
        if (uMain.uState.CurrentState != UNITSTATE.ATTACK)
        {
            uMain.uMovement.ResetState();
        }
    }
       
    IEnumerator AddForceJumpWallCoroutine()
    {
        int i = 0;
        yield return new WaitForFixedUpdate();
        while (i < jumpWallIterationsNum)
        {
            if (StatesJump.Contains(uMain.uState.CurrentState))
            {
                uMain.rb.velocity = new Vector3(wallJumpDirection * WallJumpSpeedX, WallJumpSpeedY);
            }                
            i++;

            yield return new WaitForFixedUpdate();
        }
        uMain.uMovement.ResetState();
    }
    
    IEnumerator AddForceJumpSecondCoroutine()
    {
        int i = 0;
        yield return new WaitForFixedUpdate();
        while (i < jumpSecondIterationsNum)
        {
            if (StatesJump.Contains(uMain.uState.CurrentState))
            {
                uMain.rb.velocity = new Vector3(uMain.rb.velocity.x, SecondJumpSpeed);
            }                
            i++;

            yield return new WaitForFixedUpdate();
        }
        uMain.uMovement.ResetState();
    }

    IEnumerator OffSkipPlatformCorutine()
    {
        while (uMain.uCollisions.IsTouchingPlatform(platform))
        {
            if (uMain.uCollisions.IsTouchingNewPlatform(platform) && uMain.uState.CurrentState == UNITSTATE.JUMPDOWN)
            {
                uMain.uState.CurrentState = UNITSTATE.IDLE;
            }
            yield return new WaitForFixedUpdate();
        }
        if (uMain.uState.CurrentState == UNITSTATE.JUMPDOWN)
        {
            uMain.uState.CurrentState = UNITSTATE.FALL;
        }
        Physics2D.IgnoreCollision(transform.gameObject.GetComponent<Collider2D>(), platform.GetComponent<Collider2D>(), false);
    }

    [System.Serializable]
    public class JumpSurfaceSettings
    {
        public MATERIALS surfaceTag;
        public string jumpSFX;
        public GameObject jumpVFX;
        public GameObject wJumpVFX;
    }

}