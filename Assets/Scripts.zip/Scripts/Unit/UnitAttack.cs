using UnityEngine;

public abstract class UnitAttack : MonoBehaviour
{
    public abstract void OnAttack();
}
