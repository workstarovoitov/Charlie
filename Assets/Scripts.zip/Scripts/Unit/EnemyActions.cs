using UnityEngine;
using System.Collections.Generic;

public class EnemyActions : MonoBehaviour
{
	private UnitMain uMain;
	private GameObject targetAttack;                        //current target
	
	[SerializeField] private bool randomizeValues = false;

	[Header("Waypoints settings")]
	[SerializeField] private GameObject[] waypoints;
	[SerializeField] private float waypointWaitTime;
	[SerializeField] private float rangeMarging = 0.5f;		//the amount of space that is allowed between the player and enemy before we reposition ourselves
	private int currentWaypointIndex = 0;
	private float waypointSpottedTime = 0;
	private bool waypointSpotted = false;
	private Vector2 simpleMoveDirection = Vector2.right;

	[Header("Attack distance")]
	[SerializeField] private float hitAngleRange = 15f;		//the y range of all attacks
	[SerializeField] private float sightDistance = 5f;		//the distance when we can see the target
	[SerializeField] private float attackInterval = 2f;     //the time between attacking
	[SerializeField] private float distanceToKeep = 3f;     //the distance from the target at close range
	[SerializeField] private LayerMask WallsLayer;

	private float lastAttackTime = 0;
	
	private UnitAttack[] attacks;

	[SerializeField] private ENEMYTACTIC currentEnemyTactic;
	public ENEMYTACTIC CurrentEnemyTactic
	{
		get => currentEnemyTactic;
		set
		{
			currentEnemyTactic = value;
		}
	}

	[SerializeField] private bool enableAI;
	public bool EnableAI
	{
		get => enableAI;
		set => enableAI = value;
	}
	
	[SerializeField] private bool lookOnTarget = false;

	private List<UNITSTATE> ActiveAIStates = new List<UNITSTATE>
	{
		UNITSTATE.IDLE,
		UNITSTATE.SLEEP,
		UNITSTATE.WALK,
		UNITSTATE.FALL,
	};

	void Start()
	{
		if (!uMain) uMain = GetComponent<UnitMain>();
		attacks = GetComponents<UnitAttack>();
		if (!targetAttack)
		{
			targetAttack = GameObject.FindGameObjectWithTag("Player");
		}
		simpleMoveDirection = simpleMoveDirection * (int) uMain.uMovement.CurrentDirection;
		if (randomizeValues)
        {
			GetComponent<Animator>().speed = Random.Range(0.8f, 1.2f);
        }
	}

    private void OnEnable()
    {
		waypointSpotted = false;
		waypointSpottedTime = 0;
		lastAttackTime = 0;
	}

	void Update()
	{
		if (!enableAI) return;
		if (!targetAttack)
		{
			targetAttack = GameObject.FindGameObjectWithTag("Player");
		}

		if (uMain.uState.CurrentState == UNITSTATE.DEATH)
		{
			enableAI = false;
			return;
		}

		if (ActiveAIStates.Contains(uMain.uState.CurrentState))
		{
			AI();
		}
	}

	void AI()
	{
		if (attacks.Length > 0)
		{
			if (lookOnTarget && IsTargetSpotted(targetAttack))
			{
				LookAtTarget(targetAttack);
			}


			if (Time.time - lastAttackTime > attackInterval)
			{
				if (InVerticalRangedAttackRange(targetAttack) && IsTargetSpotted(targetAttack))
				{
					Attack();
				}
			}
		}

		switch (currentEnemyTactic)
		{
			case ENEMYTACTIC.MOVE:
				MoveBetweenWalls();
				break;

			case ENEMYTACTIC.MOVETOCLIFF:
				MoveBetweenObstacles();
				break;

			case ENEMYTACTIC.PATROL:
				MovePatrool();
				break;

			case ENEMYTACTIC.KEEPDISTANCE:
				WalkTo(targetAttack, distanceToKeep, rangeMarging);
				break;

			case ENEMYTACTIC.CHILL:
				uMain.uMovement.OnMove(Vector2.zero);
				break;
		}
	}

	//move between obstacles
	public void MoveBetweenWalls()
    {
		//if we stay cause obstacle change direction immediately
		if (ObstaclesCheck(false))
		{
			uMain.uMovement.ReverseDirection();
			simpleMoveDirection *= -1;
		}
		uMain.uMovement.OnMove(simpleMoveDirection);
	}
	//move between obstacles
	public void MoveBetweenObstacles()
    {
		//if enemy stay enough move to next waypoint
		if (Time.time - waypointSpottedTime > waypointWaitTime && waypointSpotted)
		{
			waypointSpotted = false;
			//if we stay cause obstacle change direction immediately
			if (ObstaclesCheck())
			{
				uMain.uMovement.ReverseDirection();
				simpleMoveDirection *= -1;
			}
		}

		//if enemy reach obstacle ...
		if (ObstaclesCheck() && !waypointSpotted)
		{
			waypointSpottedTime = Time.time;
			waypointSpotted = true;
		}

		//... stopped or move to waypoint
		if (waypointSpotted)
		{
			uMain.uMovement.OnMove(Vector2.zero);
		}
		else
		{
			uMain.uMovement.OnMove(simpleMoveDirection);
		}

	}

	//move between waypoints
	public void MovePatrool()
	{
		if (waypoints.Length == 0)
		{
			currentEnemyTactic = ENEMYTACTIC.MOVETOCLIFF;
		}

		//if enemy stay enough move to next waypoint
		if (Time.time - waypointSpottedTime > waypointWaitTime && waypointSpotted)
		{
			waypointSpotted = false;
			currentWaypointIndex++;

			if (currentWaypointIndex >= waypoints.Length)
			{
				currentWaypointIndex = 0;
			}

			//if we stay cause obstacle change direction immediately
			if (ObstaclesCheck() && !uMain.uState.Flying)
            {
				uMain.uMovement.ReverseDirection();
            }
		}

		//if enemy not on the same height with waypoint and can't fly or jump - change tactic
		if (Mathf.Abs(transform.position.y - waypoints[currentWaypointIndex].transform.position.y) > rangeMarging && !uMain.uState.Flying && !GetComponent<UnitJump>())
        {
			currentEnemyTactic = ENEMYTACTIC.MOVETOCLIFF;
		}

		//if enemy reach waypoint or obstacle ...
		if (Vector2.Distance(waypoints[currentWaypointIndex].transform.position, transform.position) < rangeMarging * 2 || (ObstaclesCheck() && !uMain.uState.Flying))
		{
            if (!waypointSpotted)
            {
				waypointSpottedTime = Time.time;
            }
			waypointSpotted = true;
        }
        else
        {
			waypointSpotted = false;
		}

		WalkTo(waypoints[currentWaypointIndex], rangeMarging, rangeMarging);
	}

	//Attack 
	public void Attack()
	{
		lastAttackTime = Time.time;
		attacks[Random.Range(0, attacks.Length)].OnAttack();
		return;
	}

	private bool IsTargetSpotted(GameObject target)
	{
		if (target == null) return false;
		if (Vector2.Distance(target.transform.position, transform.position) > sightDistance) return false;

		return !Physics2D.Raycast(transform.position, target.transform.position - transform.position, (target.transform.position - transform.position).magnitude, WallsLayer);
	}

	public void LookAtTarget(GameObject target)
	{
		if (target == null) return;

		int dir = target.transform.position.x >= transform.position.x ? 1 : -1;
		uMain.uMovement.SetDirection((DIRECTION)dir);
	}

	//check target in front of enemy
	private bool InVerticalRangedAttackRange(GameObject target)
	{
		Vector2 distance = target.transform.position - transform.position;
		int dir = uMain.transform.rotation.y == 0 ? 1 : -1;
		if (dir * (target.transform.position.x - transform.position.x) < 0)
        {
			return false;
        }

		if (distance.magnitude > sightDistance)
        {
			return false;
        }

		float angle = Mathf.Atan2(distance.y, distance.x) * Mathf.Rad2Deg;
		if (Mathf.Abs(angle) < hitAngleRange || 180f - Mathf.Abs(angle) < hitAngleRange)
		{
			return true;
		}

		return false;
	}

	//walk to target
	public void WalkTo(GameObject destination, float proximityRange, float movementMargin)
	{

		Vector2 dirToTarget = destination.transform.position - transform.position;
		float dist = Vector2.Distance(destination.transform.position, transform.position);
		Vector2 moveDirection = Vector2.zero;


		if (dist >= proximityRange)
		{
			moveDirection = new Vector2(dirToTarget.x, dirToTarget.y);
		}
		//we are too close, move away
		if (dist <= proximityRange - movementMargin)
		{
			moveDirection = new Vector2(-dirToTarget.x, dirToTarget.y);
		}

		if (uMain.uState.CurrentGroundedState && !uMain.uState.Flying)
		{
			uMain.uMovement.OnMove(moveDirection.normalized);
			return;
		}

		if (uMain.uState.Flying)
		{
			uMain.uMovement.OnMove(new Vector2(Mathf.Clamp(dirToTarget.x, -1, 1), Mathf.Clamp(dirToTarget.y, -1, 1)));
			return;
		}
	}

	//check walls and cliffs in front of enemy
	private bool ObstaclesCheck(bool cliffCheck = true)
	{
		if ((cliffCheck && uMain.uCollisions.CliffInFrontX() && !uMain.uState.Flying) || (uMain.uCollisions.WallInFrontX() && !uMain.uCollisions.BlockInFrontX()))
		{
			return true;
		}
		return false;
	}
}

public enum ENEMYTACTIC
{
	ENGAGE = 0,
	KEEPDISTANCE = 1,

	MOVE = 4,
	MOVETOCLIFF = 5,
	PATROL = 6,
	CHILL = 7,
}
