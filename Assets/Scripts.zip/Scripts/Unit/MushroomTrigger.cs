using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MushroomTrigger : MonoBehaviour
{
	void OnTriggerEnter2D(Collider2D col)
	{
		if (col.gameObject.CompareTag("Mushroom"))
		{
			GetComponent<EnemySpawner>().Spawn();
			Destroy(col.gameObject);
		}
	}
}
