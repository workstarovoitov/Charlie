using UnityEngine;

[RequireComponent(typeof(UnitMain))]

class SlimeMove : MonoBehaviour
{
    private UnitMain uMain;
    [SerializeField] private string moveSFX;

    void Start()
    {
        if (!uMain) uMain = GetComponent<UnitMain>();
    }

    public void AE_StartMove()
    {
        GetComponent<EnemyActions>().CurrentEnemyTactic = ENEMYTACTIC.MOVE;
    }  
    public void AE_StoptMove()
    {
        GetComponent<EnemyActions>().CurrentEnemyTactic = ENEMYTACTIC.CHILL;
    }  
    public void AE_MoveSFX()
    {
        uMain.uSFX.PlaySFX(moveSFX);
    }
}